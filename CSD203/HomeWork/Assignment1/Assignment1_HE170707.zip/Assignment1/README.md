# :smiley: SaleManagementSystem

## 🃏 Introduction

This is a simulation of simple sale management system.

## 🐍 Prerequisite

Python >= 3.10

## 🚀 Installation

Clone the repo and run main.py:

```pwsh
git clone https://github.com/hungpham3112/SaleManagementSystem.git && cd SaleManagementSystem
python main.py
```

## Licenses
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
