class Car:
    def __init__(self, name="", price=-1):
        self.name = name
        self.price = price
    def __repr__(self):
        return f"({self.name}, {self.price})"    