from Car import *
class NodeQ:
    def __init__(a,data):
        a.data = data
        a.next = None
class MyQueue:
    def __init__(a):
        a.head = None
        a.tail = None
    def isEmpty(a):
        return a.head ==None
    def EnQueue(a, data):
        node = NodeQ(data)
        if a.isEmpty():
            a.head = node
            a.tail = node
        else:
            a.tail.next = node
            a.tail = node
    #end def
    def DeQueue(a):
        if a.isEmpty():
            return None
        data = a.head.data
        a.head = a.head.next
        return data
#end class    
class Node:
    def __init__(a,data):
        a.data = data
        a.left = None
        a.right = None
    #end def    
#end class
class BSTree:
    def __init__(a):
        a.root = None
    # end def
    def clear(self):
        self.root = None
    def isEmpty(a):
        return a.root == None
    #end def
    def insert(a,name, xprice):
        # ===YOU CAN EDIT OR EVEN ADD NEW FUNCTIONS IN THE FOLLOWING PART========


        #########################
        pass
    #end def
    def visit(a,p):
        if p==None:
            return
        print(f"{p.data}",end =" ")
    #end def
    def preOrder(a,p):
        if p==None:
            return
        a.visit(p)
        a.preOrder(p.left)
        a.preOrder(p.right)
    #end def
    def preVisit(a):
        a.preOrder(a.root)
        print("")
    #end def
    
    def preVisit2(a):
        a.preOrder2(a.root)
        print("")
    #end def
    def postOrder(a,p):
        if p==None:
            return
        a.postOrder(p.left)
        a.postOrder(p.right)
        a.visit(p)
    #end def
    def postVisit(a):
        a.postOrder(a.root)
        print("")
    #end def
    def inOrder(a,p):
        if p==None:
            return
        a.inOrder(p.left)
        a.visit(p)
        a.inOrder(p.right)        
    #end def
    def inVisit(a):
        a.inOrder(a.root)
        print("")
    #end def
    def breadth_first(a):
        if a.isEmpty():
            return
        my = MyQueue()
        my.EnQueue(a.root)
        while not my.isEmpty():
            p = my.DeQueue()
            a.visit(p)
            if p.left!=None:
                my.EnQueue(p.left)
            if p.right!=None:
                my.EnQueue(p.right)
        print("")        
    #end def
    def f2(self,name=[],price =[]):
        for i in range(len(name)):
            self.insert(name[i],price[i])
        self.preVisit()
        # ===YOU CAN EDIT OR EVEN ADD NEW FUNCTIONS IN THE FOLLOWING PART========
    



        ####################
  
    def f3(self,name =[], price=[]):
        for i in range(len(name)):
            self.insert(name[i],int(price[i]))
        self.breadth_first() 
        # ===YOU CAN EDIT OR EVEN ADD NEW FUNCTIONS IN THE FOLLOWING PART========
        
        
        #############################    
        self.breadth_first()        
    def f4(self, name=[], price=[]):
        for i in range(len(name)):
            self.insert(name[i],price[i])
        self.breadth_first()
        #  ===YOU CAN EDIT OR EVEN ADD NEW FUNCTIONS IN THE FOLLOWING PART========


        #################################
        self.breadth_first()


# end class
